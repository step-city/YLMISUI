<template>
<div>
加载出错了....
</div>
</template>

<script type="text/babel">
export default {
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="stylus" rel="stylesheet/stylus" scoped>
</style>
