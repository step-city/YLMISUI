import * as mock from './mock';

export default mock;