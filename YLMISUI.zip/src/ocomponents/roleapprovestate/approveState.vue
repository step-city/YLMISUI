
<template>
<div class="approve">
    <div class="level aside">
        <div class="item">
            <div class="row one" >
                <div class="column"></div>
                <div class="column"> <span class="text">发起</span></div>
                <div class="column"><i class="icon-arrow-left2"></i></div>
            </div>
             <div class="row one" >
                <div class="column"></div>
                <div class="column"> <i class="icon-arrow-down2"></i></div>
                <div class="column"></div>
            </div>
            <div class="row one">
                <div class="column"></div>
                <div class="column"> <i class="icon-arrow-down2"></i></div>
                <div class="column"></div>
            </div>
        </div>
         <div class="item">
            <div class="row one">
                <div class="column"><i class="icon-arrow-left2"></i></div>
                <div class="column"> <i class="icon-arrow-up-left2"></i></div>
                <div class="column"></div>
            </div>
             <div class="row one">
                <div class="column"></div>
                <div class="column eventbh"><i class="icon-user-minus"></i><span class="text">驳回</span></div>
                <div class="column"></div>
            </div>
            <div class="row one">
                <div class="column"></div>
                <div class="column"> <i class="icon-arrow-up2"></i></div>
                <div class="column"></div>
            </div>
        </div>
    </div>
    <div class="level floor">
        <div class="item">
            <div class="row two">
                <div class="column"></div>
                <div class="column"> <i class="icon-number11"></i><span class="text">库管员审批</span></div>
                <div class="column"><i class="icon-loop3"></i></div>
            </div>
            <div class="row two">
                <div class="column"></div>
                <div class="column"> <i class="icon-arrow-down2"></i></div>
                <div class="column"></div>
            </div>
            <div class="row two">
                <div class="column"></div>
                <div class="column eventtg">
                            <el-tooltip placement="right">
                                 <div slot="content">审批人：XXXX 审批时间：2017-06-06  审批意见：通过！<br/>
                                                    审批人：XXXX 审批时间：2017-06-06  审批意见：通过！<br/>
                                                    审批人：XXXX 审批时间：2017-06-06  审批意见：通过！<br/>
                                 </div>
                                <i class="icon-user-check"></i>
                            </el-tooltip>
                             <span class="text">通过</span>
                 </div>
                <div class="column"></div>
            </div>
            <div class="row two">
                <div class="column"></div>
                <div class="column"> <i class="icon-arrow-down2"></i></div>
                <div class="column"></div>
            </div>
        </div>
        <div class="item">
            <div class="row two">
                <div class="column"><i class="icon-loop3"></i></div>
                <div class="column"> </div>
                <div class="column"></div>
            </div>
            <div class="row two">
                <div class="column"></div>
                <div class="column"> <i class="icon-arrow-up-left2"></i></div>
                <div class="column"></div>
            </div>
            <div class="row two">
                <div class="column"></div>
                <div class="column eventbh"><i class="icon-user-minus"></i><span class="text">驳回</span></div>
                <div class="column"></div>
            </div>
            <div class="row two">
                <div class="column"></div>
                <div class="column"> <i class="icon-arrow-up2"></i></div>
                <div class="column"></div>
            </div>
        </div>
    </div>
    <div class="level floor">
        <div class="item">
            <div class="row two">
                <div class="column"></div>
                <div class="column"> <i class="icon-number12"></i><span class="text">公司管理员审批</span></div>
                <div class="column"><i class="icon-loop3"></i></div>
            </div>
            <div class="row two">
                <div class="column"></div>
                <div class="column"> <i class="icon-arrow-down2"></i></div>
                <div class="column"></div>
            </div>
            <div class="row two">
                <div class="column"></div>
                <div class="column eventtg"><i class="icon-user-check"></i><span class="text">通过</span></div>
                <div class="column"></div>
            </div>
            <div class="row two">
                <div class="column"></div>
                <div class="column"> <i class="icon-arrow-down2"></i></div>
                <div class="column"></div>
            </div>
        </div>
        <div class="item">
            <div class="row two">
                <div class="column"><i class="icon-loop3"></i></div>
                <div class="column"> </div>
                <div class="column"></div>
            </div>
            <div class="row two">
                <div class="column"></div>
                <div class="column"> <i class="icon-arrow-up-left2"></i></div>
                <div class="column"></div>
            </div>
            <div class="row two">
                <div class="column"></div>
                <div class="column eventbh"><i class="icon-user-minus"></i><span class="text">驳回</span></div>
                <div class="column"></div>
            </div>
            <div class="row two">
                <div class="column"></div>
                <div class="column"> <i class="icon-arrow-up2"></i></div>
                <div class="column"></div>
            </div>
        </div>
    </div>
    <div class="level floor">
        <div class="item">
            <div class="row two">
                <div class="column"></div>
                <div class="column"> <i class="icon-number13"></i><span class="text">超级管理员审批</span></div>
                <div class="column"><i class="icon-loop3"></i></div>
            </div>
            <div class="row two">
                <div class="column"></div>
                <div class="column"> <i class="icon-arrow-down2"></i></div>
                <div class="column"></div>
            </div>
            <div class="row two">
                <div class="column"></div>
                <div class="column eventtg"><i class="icon-user-check"></i><span class="text">通过</span></div>
                <div class="column"></div>
            </div>
            <div class="row two">
                <div class="column"></div>
                <div class="column"> <i class="icon-arrow-down2"></i></div>
                <div class="column"></div>
            </div>
        </div>
        <div class="item">
            <div class="row two">
                <div class="column"><i class="icon-loop3"></i></div>
                <div class="column"> </div>
                <div class="column"></div>
            </div>
            <div class="row two">
                <div class="column"></div>
                <div class="column"></div>
                <div class="column"></div>
            </div>
            <div class="row two">
                <div class="column"></div>
                <div class="column "></div>
                <div class="column"></div>
            </div>
            <div class="row two">
                <div class="column"></div>
                <div class="column"> </div>
                <div class="column"></div>
            </div>
        </div>
    </div>
    <div class="level">
        <div class="item"><i class="icon-flag"></i>结束</div>
        <div class="item"></div>
    </div>
</div>
</template>

<script type="text/babel">
export default {
    data(){
        return{
        }      
    },
    methods:{
    },
    components:{
    },
     mounted(){
    },
     watch:{
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="stylus" rel="stylesheet/stylus" scoped>
.approve
    padding:5px
    height:100%
    width:100%
    font-size:14px
    display:flex
    flex-direction:column
    flex-wrap:nowrap
    justify-content: space-around
    align-items: stretch
    text-align:center
    .aside
        height:90px
    .floor
        height:120px
    .level
        display:flex
        justify-content: space-around
        align-items: center
        .item
            width:50%
            height:100%
            .one
                height:34%
            .two
                height:25%
            .row
                width:100%
                display:flex
                justify-content: space-around
                align-items:center
                .column
                    width:34%
                .eventtg
                    padding:2px
                    background:#13CE66
                    color:#fff
                    border:1px solid #20A0FF
                .eventbh
                    padding:2px
                    background:#FF4949
                    color:#fff
                    border:1px solid #20A0FF
</style>
