//全局配置文件
export default{
	//api访问地址
	baseURL:'http://192.168.20.32',
	client_id:'123',
	client_secret:'456',
	timeout:'90000', //请求响应时间
	tableConf:{
		limitCount:20,
	},
	Order:{
		title:'一局电务公司',
	},
	reportUrl:'http://117.34.112.55:8070',
  }
